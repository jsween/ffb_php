--
-- Database: `ffb_tool_db`
--
CREATE DATABASE IF NOT EXISTS `ffb_tool_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ffb_tool_db`;

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `avg_fifteen` decimal(3,1) DEFAULT NULL,
  `consistency` int(11) DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `photo_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`id`, `name`, `avg_fifteen`, `consistency`, `position_id`, `team_id`, `photo_url`) VALUES
(1, 'Cam Newton', '23.2', 82, 1, 5, 'camnewton.png'),
(2, 'Tom Brady', '20.9', 87, 1, 20, 'tombrady.png'),
(3, 'Russell Wilson', '20.1', 86, 1, 29, 'russellwilson.png'),
(4, 'Blake Bortles', '18.9', 84, 1, 15, 'blakebortles.png'),
(5, 'Carson Palmer', '18.8', 90, 1, 7, 'carsonpalmer.png'),
(6, 'Drew Brees', '18.7', 80, 1, 21, 'drewbrees.png'),
(7, 'Aaron Rodgers', '17.9', 85, 1, 12, 'aaronrodgers.png'),
(8, 'Kirk Cousins', '17.7', 81, 1, 32, 'kirkcousins.png'),
(9, 'Matthew Stafford', '17.5', 84, 1, 11, 'matthewstafford.png\r\n'),
(10, 'Eli Manning', '17.4', 82, 1, 22, 'elimanning.png\n'),
(11, 'Devonta Freeman', '14.4', 79, 2, 2, 'devontafreeman.png\r\n'),
(12, 'Adrian Peterson', '13.6', 84, 2, 19, 'adrianpeterson.png\n'),
(13, 'Doug Martin', '11.7', 84, 2, 19, 'dougmartin.png'),
(14, 'DeAngelo Williams', '11.2', 78, 2, 26, 'deangelowilliams.png'),
(15, 'Todd Gurley', '11.0', 84, 2, 17, 'toddgurley.png'),
(16, 'Lamar Miller', '10.8', 81, 2, 13, 'lamarmiller.png'),
(17, 'David Johnson', '10.3', 80, 2, 1, 'davidjohnson.png'),
(18, 'Matt Forte', '9.9', 90, 2, 6, 'mattforte.png'),
(19, 'Chris Ivory', '9.9', 85, 2, 23, 'chrisivory.png'),
(20, 'Danny Woodhead', '9.3', 84, 2, 27, 'dannywoodhead.png');

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `position_name` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`id`, `position_name`) VALUES
(1, 'Quarterback'),
(2, 'Running Back'),
(3, 'Wide Receiver'),
(4, 'Tight End'),
(5, 'Team Defense/Special Teams'),
(6, 'Place Kicker');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_name` varchar(55) DEFAULT NULL,
  `logo` varchar(55) DEFAULT NULL,
  `abbreviation` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `team_name`, `logo`, `abbreviation`) VALUES
(1, 'Arizona Cardinals', 'arizona', 'ARI'),
(2, 'Atlanta Falcons', 'atlanta', 'ATL'),
(3, 'Baltimore Ravens', 'baltimore', 'BAL'),
(4, 'Buffalo Bills', 'buffalo', 'BUF'),
(5, 'Carolina Panthers', 'carolina', 'CAR'),
(6, 'Chicago Bears', 'chicago', 'CHI'),
(7, 'Cincinnati Bengals', 'cincinnati', 'CIN'),
(8, 'Cleveland Browns', 'cleveland', 'CLE'),
(9, 'Dallas Cowboys', 'dallas', 'DAL'),
(10, 'Denver Broncos', 'denver', 'DEN'),
(11, 'Detroit Lions', 'detroit', 'DET'),
(12, 'Green Bay Packers', 'greenbay', 'GB'),
(13, 'Houston Texans', 'houston', 'HOU'),
(14, 'Indianapolis Colts', 'indianapolis', 'IND'),
(15, 'Jacksonville Jaguars', 'jacksonville', 'JAX'),
(16, 'Kansas City Chiefs', 'kansascity', 'KC'),
(17, 'Los Angeles Rams', 'losangeles', 'LA'),
(18, 'Miami Dolphins', 'miami', 'MIA'),
(19, 'Minnesota Vikings', 'minnesota', 'MIN'),
(20, 'New England Patriots', 'newengland', 'NE'),
(21, 'New Orleans Saints', 'neworleans', 'NO'),
(22, 'New York Giants', 'newyorkg', 'NYG'),
(23, 'New York Jets', 'newyorkj', 'NYJ'),
(24, 'Oakland Raiders', 'oakland', 'OAK'),
(25, 'Philadelphia Eagles', 'philadelphia', 'PHI'),
(26, 'Pittsburgh Steelers', 'pittsburgh', 'PIT'),
(27, 'San Diego Chargers', 'sandiego', 'SD'),
(28, 'San Francisco 49ers', 'sanfrancisco', 'SF'),
(29, 'Seattle Seahawks', 'seattle', 'SEA'),
(30, 'Tampa Bay Buccaneers', 'tampabay', 'TB'),
(31, 'Tennessee Titans', 'tennessee', 'TEN'),
(32, 'Washington Redskins', 'washington', 'WAS');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist_players`
--

CREATE TABLE `wishlist_players` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `wish_list_id` int(11) DEFAULT NULL,
  `player_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wish_list`
--

CREATE TABLE `wish_list` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wish_list`
--

INSERT INTO `wish_list` (`id`, `name`) VALUES
(1, 'My Wish List');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `wishlist_players`
--
ALTER TABLE `wishlist_players`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `wish_list`
--
ALTER TABLE `wish_list`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `wishlist_players`
--
ALTER TABLE `wishlist_players`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wish_list`
--
ALTER TABLE `wish_list`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
